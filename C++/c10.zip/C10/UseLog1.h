//: C10:UseLog1.h
// From "Thinking in C++, 2nd Edition, Volume 2"
// by Bruce Eckel & Chuck Allison, (c) 2003 MindView, Inc.
// Available at www.BruceEckel.com.
#ifndef USELOG1_H
#define USELOG1_H
void f();
#endif // USELOG1_H ///:~
