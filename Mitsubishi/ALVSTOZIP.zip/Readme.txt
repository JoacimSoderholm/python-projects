File : README.TXT
                                                        November 2011
                       SW0D5-ALVLS-EU

                       (Version 2.70)
-----------------------------------------------------------------------

CONTENTS

  1. Introduction
  2. System Requirements
  3. Installing SW0D5-ALVLS-EU
  4. Where to Find More Information
  5. Program Notes

-----------------------------------------------------------------------
1. INTRODUCTION
-----------------------------------------------------------------------
Thank you for installing the SW0D5-ALVLS-EU (Version 2.70)

This software is being developed by Mitsubishi Electric Corporation,
Himeji Works, Japan.

IMPORTANT: Please make sure you understand the Copyright and License
information before installing this release.

-----------------------------------------------------------------------
2. SYSTEM REQUIREMENTS
-----------------------------------------------------------------------
Before installing the software, please make sure that
you have the following system requirements,

Machine    : Pentium133 MHz or more (recommended)
OS         : Windows 95/98/Me or Windows NT4.0/2000/XP/Vista/7 (Intel)
RAM        : 32 MB is preferable
Disk Space : Approximately 10 MB
Video      : SVGA (800 x 600) 256 colors or more (recommended)


-----------------------------------------------------------------------
3. INSTALLING SW0D5-ALVLS-EU
-----------------------------------------------------------------------
SW0D5-ALVLS-E installation is provided in CD.

Here are the abbreviated instructions.

1. SW0D5-ALVLS-EU setup will guide you through the rest of the
   installation procedure.  Choose the installation directory and
   Program group.

2. Once installation is successful, SW0D5-ALVLS-EU creates Program group
   Mitsubishi Alpha Controller which consists of the following icons,

   - Alpha Programming (Application)
   - Help    (Help file)
   - READ ME (readme.txt file)


-----------------------------------------------------------------------
4. WHERE TO FIND MORE INFORMATION
-----------------------------------------------------------------------
For more information on VLS software,

1. HELP File.
   - Click on the HELP icon which is provided by the
     SW0D5-ALVLS-EU installation.
   - Online help is provided with the application.

2. Read the This Documents, which are provided by
   Mitsubishi Electric Corporation, Japan.


-----------------------------------------------------------------------
5. PROGRAM NOTES
-----------------------------------------------------------------------
Information concerning Auto-Tuning and VLS monitoring

 Upon the completion of Auto-Tuning, the program in the controller 
 will be updated with the tuned PID parameters. If VLS was monitoring 
 the controller before the Auto-Tuning function was started, 
 monitoring will STOP, a message box will appear and VLS will return 
 to the Editing mode. The updated program must be uploaded to the PC 
 to begin monitoring again.

-----------------------------------------------------------------------

